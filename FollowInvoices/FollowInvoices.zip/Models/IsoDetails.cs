﻿using System;
using System.Numerics;
namespace FollowInvoices.Models
{
    public class IsoDetails
    {
        public string ID { get; set; }
        public string Date { get; set; }
    }
}
