﻿using ClosedXML.Excel;
using Microsoft.Extensions.Options;
using FollowInvoices.Models;
using FollowInvoices.Utilities;
using System.Data.SqlClient;
using System.Diagnostics;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting.Internal;
using System.IO;
using FollowInvoices.Data;
using DocumentFormat.OpenXml.InkML;
using Azure.Core;
using DocumentFormat.OpenXml.VariantTypes;
using DocumentFormat.OpenXml.EMMA;
using Microsoft.AspNetCore.Authorization;
using DocumentFormat.OpenXml.Office2010.Excel;
using System.Numerics;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.Reflection.Metadata;

namespace FollowInvoices.Controllers
{
    //[Authorize]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IOptions<AppSettings> _options;
        private readonly IWebHostEnvironment _hostingEnvironment;
        public HomeController(ILogger<HomeController> logger, IOptions<AppSettings> options, IWebHostEnvironment hostingEnvironment)
        {
            _logger = logger;
            _options = options;
            _hostingEnvironment = hostingEnvironment;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpGet]
        public IActionResult ExecuteCreate(string id, string isoDate, string invoiceNumber, string invoiceDescription, string contractDescription,
            string vendorCode, string vendorName, string invoiceValue, string currency, string invoiceStatus, string invoiceSapStatus,
            string invoiceDate, string invoiceReceiptDate, string requester, string userName)
        {
            string connectionString = "Data Source=(local);Initial Catalog=FollowInvoices;Integrated Security=True;";
            string isoNumber;
            IsoDetails isoDetails = new IsoDetails();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open(); // Open the connection here

                // Check if the ID already exists
                string getId = @"SELECT Id FROM InvoiceDetails WHERE Id = @Id";
                using (SqlCommand command = new SqlCommand(getId, connection))
                {
                    command.Parameters.AddWithValue("@Id", id);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            ViewBag.ErrorMessage = "!رقم المتابعة المدخل مكرر";
                            return View("Failed");
                        }
                    }
                }

                // Insert into InvoiceDetails
                string insertQueryIntoInvoiceDetails = @"
            INSERT INTO InvoiceDetails (Id, IsoDate, InvoiceNumber, Descriptio, Contrac, VendorCode, VendorName, Valu, Currency, SapStatus, Dat, Requester, UserName)
                                VALUES (@Id, @IsoDate, @InvoiceNumber, @Descriptio, @Contrac, @VendorCode, @VendorName, @Valu, @Currency, @SapStatus, @Dat, @Requester, @UserName)
                                SELECT SCOPE_IDENTITY();;
        ";

                using (SqlCommand command = new SqlCommand(insertQueryIntoInvoiceDetails, connection))
                {
                    command.Parameters.AddWithValue("@Id", id);
                    command.Parameters.AddWithValue("@IsoDate", DateTime.Today);
                    command.Parameters.AddWithValue("@InvoiceNumber", invoiceNumber);
                    command.Parameters.AddWithValue("@Descriptio", invoiceDescription);
                    command.Parameters.AddWithValue("@Contrac", contractDescription);
                    command.Parameters.AddWithValue("@VendorCode", vendorCode);
                    command.Parameters.AddWithValue("@VendorName", vendorName);
                    command.Parameters.AddWithValue("@Valu", invoiceValue);
                    command.Parameters.AddWithValue("@Currency", currency);
                    command.Parameters.AddWithValue("@SapStatus", invoiceSapStatus);
                    command.Parameters.AddWithValue("@Dat", invoiceDate);
                    command.Parameters.AddWithValue("@Requester", requester);
                    command.Parameters.AddWithValue("@UserName", userName);

                    try
                    {
                        //command.ExecuteNonQuery();
                        isoNumber = command.ExecuteScalar().ToString();
                        isoDetails.ID = isoNumber;
                        isoDetails.Date = isoDate;
                    }
                    catch (Exception ex)
                    {
                        //ViewBag.ErrorMessage = ex.Message;
                        ViewBag.ErrorMessage = ".يرجي التأكد من ادخال كل البيانات بطريقة صحيحة";
                        return View("Failed");
                    }
                }

                // Insert into History
                string insertQueryIntoHistory = @"
            INSERT INTO History (Id, InvoiceStatus, Dat)
            VALUES (@InvoiceNumber, @InvoiceStatus, @ReceiptDate)
        ";

                using (SqlCommand command = new SqlCommand(insertQueryIntoHistory, connection))
                {
                    command.Parameters.AddWithValue("@InvoiceNumber", invoiceNumber);
                    command.Parameters.AddWithValue("@InvoiceStatus", invoiceStatus);
                    command.Parameters.AddWithValue("@ReceiptDate", invoiceReceiptDate);

                    try
                    {
                        command.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        ViewBag.ErrorMessage = ".يرجي التأكد من ادخال كل البيانات بطريقة صحيحة";
                        //ViewBag.ErrorMessage = ex.Message;
                        return View("Failed");
                    }
                }                
            }

            // Redirect to another action after the insert
            return View("DoneCreate", isoDetails);
        }

        public IActionResult Exchange()
        {
            return View();
        }
        [HttpGet]
        public IActionResult ExecuteExchange(string id, string exchangeNumber)
        {
            string connectionString = "Data Source=(local);Initial Catalog=FollowInvoices;Integrated Security=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string getId = @"SELECT Id FROM InvoiceDetails WHERE Id = @Id";

                // Execute your SQL query using the connection
                using (SqlCommand command = new SqlCommand(getId, connection))
                {
                    // Add parameters to the command
                    command.Parameters.AddWithValue("@Id", id);

                    // Execute the command and retrieve data
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        // Check if the DataTable has data
                        if (!(dt.Rows.Count > 0))
                        {
                            ViewBag.ErrorMessage = ".يجب اضافة الفاتورة أولا";
                            return View("Failed");
                        }
                    }
                }
                #region InvoiceDetails
                // Create the insert query with parameters to prevent SQL injection
                string insertQuery = @"UPDATE InvoiceDetails SET ExchangeNumber = @ExchangeNumber WHERE Id = @Id";

                // Execute the insert query using a parameterized SqlCommand
                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    // Add parameters to the command
                    command.Parameters.AddWithValue("@Id", id);
                    command.Parameters.AddWithValue("@ExchangeNumber", exchangeNumber);

                    try
                    {
                        command.ExecuteNonQuery();
                        //throw new Exception("An error occurred.");
                    }
                    catch (Exception ex)
                    {
                        ViewBag.ErrorMessage = "حدث خطأ فى ادخال البيانات.";
                        return View("Failed");
                    }
                }
                #endregion InvoiceDetails
                return View("DoneExchange");
            }
        }
        public IActionResult Edit()
        {
            return View();
        }
        [HttpGet]
        public IActionResult ExecuteEdit(string id, string invoiceStatus, string invoiceSapStatus)
        {

            string connectionString = "Data Source=(local);Initial Catalog=FollowInvoices;Integrated Security=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string getId = @"SELECT Id FROM InvoiceDetails WHERE Id = @Id";

                // Execute your SQL query using the connection
                using (SqlCommand command = new SqlCommand(getId, connection))
                {
                    // Add parameters to the command
                    command.Parameters.AddWithValue("@Id", id);

                    // Execute the command and retrieve data
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        // Check if the DataTable has data
                        if (!(dt.Rows.Count > 0))
                        {
                            ViewBag.ErrorMessage = ".يجب اضافة الفاتورة أولا";
                            return View("Failed");
                        }
                    }
                }
                #region InvoiceDetails
                // Create the insert query with parameters to prevent SQL injection
                string insertQuery = @"UPDATE InvoiceDetails SET Statu = @Statu , SapStatus = @SapStatus WHERE Id = @Id";

                // Execute the insert query using a parameterized SqlCommand
                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    // Add parameters to the command
                    command.Parameters.AddWithValue("@Id", id);
                    command.Parameters.AddWithValue("@Statu", invoiceStatus);
                    command.Parameters.AddWithValue("@SapStatus", invoiceSapStatus);

                    try
                    {
                        command.ExecuteNonQuery();
                        //throw new Exception("An error occurred.");
                    }
                    catch (Exception ex)
                    {
                        //ViewBag.ErrorMessage = ex.Message;
                        ViewBag.ErrorMessage = ".يرجي التأكد من ادخال كل البيانات بطريقة صحيحة";
                        return View("Failed");
                    }
                }
                #endregion InvoiceDetails
                #region History
                //Insert into InvoiceDetails
                // Create the insert query with parameters to prevent SQL injection
                string insertQueryIntoHistory = @"INSERT INTO History (Id, InvoiceStatus, Dat)
            VALUES (@Id, @InvoiceStatus, @Dat)";

                // Execute the insert query using a parameterized SqlCommand
                using (SqlCommand command = new SqlCommand(insertQueryIntoHistory, connection))
                {
                    // Add parameters to the command
                    command.Parameters.AddWithValue("@Id", id);
                    command.Parameters.AddWithValue("@InvoiceStatus", invoiceStatus);
                    command.Parameters.AddWithValue("@Dat", DateTime.Now.Date);

                    try
                    {
                        // Execute the insert command
                        command.ExecuteNonQuery();
                        //throw new Exception("An error occurred.");
                    }
                    catch (Exception ex)
                    {
                        // Pass the exception to the view
                        ViewBag.ErrorMessage = ".حدث خطأ فى ادخال البيانات";
                        return View("Failed");
                    }

                }
                #endregion
                // Redirect to another action after the insert
                return View("DoneEdit");
            }

        }
        public IActionResult Query()
        {
            return View();
        }
        public IActionResult AllVoicesReportView()
        {
            return View();
        }
        [HttpGet]
        public IActionResult AllVoicesReport()
        {
            // Connection string
            string connectionString = "Data Source=(local);Initial Catalog=FollowInvoices;Integrated Security=True;";

            // SQL query with parameterized query
            string sqlQuery = "SELECT \r\n    FORMAT(two.Dat, 'dd MMMM yyyy', 'ar-EG') AS 'تاريخ الاستلام',\r\n    two.InvoiceStatus AS 'حالة القاتورة',\r\n    one.Requester AS 'الجهه الطالبة',\r\n    FORMAT(one.Dat, 'dd MMMM yyyy', 'ar-EG') AS 'تاريخ الاستحقاق', \r\n    one.SapStatus AS 'حالة الفاتورة على ساب', \r\n    one.Currency AS 'العملة', \r\n    one.Valu AS 'قيمة الفاتورة', \r\n    one.VendorName AS 'اسم المورد', \r\n    one.VendorCode AS 'كود المورد',\r\n    one.Contrac AS 'وصف العقد', \r\n    one.Descriptio AS 'وصف الفاتورة', \r\n    one.InvoiceNumber AS 'رقم الفاتورة', \r\n    one.IsoDate AS 'تاريخ الايزو', \r\n    one.IsoNumber AS 'رقم الايزو', \r\n    one.Id AS 'رقم استعلام ساب'\r\nFROM \r\n    InvoiceDetails AS one \r\nJOIN \r\n    [dbo].[History] AS two ON one.InvoiceNumber = two.InvoiceNumber";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Execute your SQL query using the connection
                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    // Execute the command and retrieve data
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        // Create a new DataTable to hold distinct values
                        DataTable distinctDt = new DataTable();

                        // Add columns to the new DataTable based on the original DataTable's schema
                        foreach (DataColumn column in dt.Columns)
                        {
                            distinctDt.Columns.Add(column.ColumnName, column.DataType);
                        }

                        // Get distinct rows from the original DataTable
                        var distinctRows = dt.AsEnumerable().Distinct(DataRowComparer.Default);

                        // Add distinct rows to the new DataTable
                        foreach (DataRow row in distinctRows)
                        {
                            distinctDt.Rows.Add(row.ItemArray);
                        }

                        // Pass the distinct DataTable to the ViewBag
                        ViewBag.DataTable = distinctDt;

                        return View("ViewResult");
                    }
                }
            }
        }
        public IActionResult FilterBySapTempCodeReportView()
        {
            return View();
        }
        [HttpGet]
        public IActionResult FilterBySapTempCodeReport(string id)
        {
            ViewBag.Code = id;
            // Connection string
            string connectionString = "Data Source=(local);Initial Catalog=FollowInvoices;Integrated Security=True;";

            // SQL query with parameterized query
            string sqlQuery = "SELECT \r\n    FORMAT(two.Dat, 'dd MMMM yyyy', 'ar-EG') AS 'تاريخ الاستلام',\r\n    two.InvoiceStatus AS 'حالة القاتورة',\r\n    one.Requester AS 'الجهه الطالبة',\r\n    FORMAT(one.Dat, 'dd MMMM yyyy', 'ar-EG') AS 'تاريخ الاستحقاق', \r\n    one.SapStatus AS 'حالة الفاتورة على ساب', \r\n    one.Currency AS 'العملة', \r\n    one.Valu AS 'قيمة الفاتورة', \r\n    one.VendorName AS 'اسم المورد', \r\n    one.VendorCode AS 'كود المورد',\r\n    one.Contrac AS 'وصف العقد', \r\n    one.Descriptio AS 'وصف الفاتورة', \r\n    one.InvoiceNumber AS 'رقم الفاتورة', \r\n    one.IsoDate AS 'تاريخ الايزو', \r\n    one.IsoNumber AS 'رقم الايزو', \r\n    one.Id AS 'رقم استعلام ساب'\r\nFROM \r\n    InvoiceDetails AS one \r\nJOIN \r\n    [dbo].[History] AS two ON one.InvoiceNumber = two.InvoiceNumber \r\nWHERE \r\n    one.Id = @Code";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Execute your SQL query using the connection
                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    // Add parameters to the command
                    command.Parameters.AddWithValue("@Code", id);

                    // Execute the command and retrieve data
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        // Create a new DataTable to hold distinct values
                        DataTable distinctDt = new DataTable();

                        // Add columns to the new DataTable based on the original DataTable's schema
                        foreach (DataColumn column in dt.Columns)
                        {
                            distinctDt.Columns.Add(column.ColumnName, column.DataType);
                        }

                        // Get distinct rows from the original DataTable
                        var distinctRows = dt.AsEnumerable().Distinct(DataRowComparer.Default);

                        // Add distinct rows to the new DataTable
                        foreach (DataRow row in distinctRows)
                        {
                            distinctDt.Rows.Add(row.ItemArray);
                        }

                        // Pass the distinct DataTable to the ViewBag
                        ViewBag.DataTable = distinctDt;

                        return View("ViewResult");
                    }

                }
            }
        }
        public IActionResult FilterByRequesterReportView()
        {
            return View();
        }
        [HttpGet]
        public IActionResult FilterByRequesterReport(string id)
        {
            ViewBag.Code = id;
            // Connection string
            string connectionString = "Data Source=(local);Initial Catalog=FollowInvoices;Integrated Security=True;";

            // SQL query with parameterized query
            string sqlQuery = "SELECT \r\n    FORMAT(two.Dat, 'dd MMMM yyyy', 'ar-EG') AS 'تاريخ الاستلام',\r\n    two.InvoiceStatus AS 'حالة القاتورة',\r\n    one.Requester AS 'الجهه الطالبة',\r\n    FORMAT(one.Dat, 'dd MMMM yyyy', 'ar-EG') AS 'تاريخ الاستحقاق', \r\n    one.SapStatus AS 'حالة الفاتورة على ساب', \r\n    one.Currency AS 'العملة', \r\n    one.Valu AS 'قيمة الفاتورة', \r\n    one.VendorName AS 'اسم المورد', \r\n    one.VendorCode AS 'كود المورد',\r\n    one.Contrac AS 'وصف العقد', \r\n    one.Descriptio AS 'وصف الفاتورة', \r\n    one.InvoiceNumber AS 'رقم الفاتورة', \r\n    one.IsoDate AS 'تاريخ الايزو', \r\n    one.IsoNumber AS 'رقم الايزو', \r\n    one.Id AS 'رقم استعلام ساب'\r\nFROM \r\n    InvoiceDetails AS one \r\nJOIN \r\n    [dbo].[History] AS two ON one.InvoiceNumber = two.InvoiceNumber \r\nWHERE \r\n    one.Requester = @Code";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Execute your SQL query using the connection
                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    // Add parameters to the command
                    command.Parameters.AddWithValue("@Code", id);

                    // Execute the command and retrieve data
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        // Create a new DataTable to hold distinct values
                        DataTable distinctDt = new DataTable();

                        // Add columns to the new DataTable based on the original DataTable's schema
                        foreach (DataColumn column in dt.Columns)
                        {
                            distinctDt.Columns.Add(column.ColumnName, column.DataType);
                        }

                        // Get distinct rows from the original DataTable
                        var distinctRows = dt.AsEnumerable().Distinct(DataRowComparer.Default);

                        // Add distinct rows to the new DataTable
                        foreach (DataRow row in distinctRows)
                        {
                            distinctDt.Rows.Add(row.ItemArray);
                        }

                        // Pass the distinct DataTable to the ViewBag
                        ViewBag.DataTable = distinctDt;

                        return View("ViewResult");
                    }

                }
            }
        }
        public IActionResult FilterByVendorReportView()
        {
            return View();
        }
        [HttpGet]
        public IActionResult FilterByVendorReport(string id)
        {
            ViewBag.Code = id;
            // Connection string
            string connectionString = "Data Source=(local);Initial Catalog=FollowInvoices;Integrated Security=True;";

            // SQL query with parameterized query
            string sqlQuery = "SELECT \r\n    FORMAT(two.Dat, 'dd MMMM yyyy', 'ar-EG') AS 'تاريخ الاستلام',\r\n    two.InvoiceStatus AS 'حالة القاتورة',\r\n    one.Requester AS 'الجهه الطالبة',\r\n    FORMAT(one.Dat, 'dd MMMM yyyy', 'ar-EG') AS 'تاريخ الاستحقاق', \r\n    one.SapStatus AS 'حالة الفاتورة على ساب', \r\n    one.Currency AS 'العملة', \r\n    one.Valu AS 'قيمة الفاتورة', \r\n    one.VendorName AS 'اسم المورد', \r\n    one.VendorCode AS 'كود المورد',\r\n    one.Contrac AS 'وصف العقد', \r\n    one.Descriptio AS 'وصف الفاتورة', \r\n    one.InvoiceNumber AS 'رقم الفاتورة', \r\n    one.IsoDate AS 'تاريخ الايزو', \r\n    one.IsoNumber AS 'رقم الايزو', \r\n    one.Id AS 'رقم استعلام ساب'\r\nFROM \r\n    InvoiceDetails AS one \r\nJOIN \r\n    [dbo].[History] AS two ON one.InvoiceNumber = two.InvoiceNumber \r\nWHERE \r\n    one.VendorName = @Code";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Execute your SQL query using the connection
                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    // Add parameters to the command
                    command.Parameters.AddWithValue("@Code", id);

                    // Execute the command and retrieve data
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        // Create a new DataTable to hold distinct values
                        DataTable distinctDt = new DataTable();

                        // Add columns to the new DataTable based on the original DataTable's schema
                        foreach (DataColumn column in dt.Columns)
                        {
                            distinctDt.Columns.Add(column.ColumnName, column.DataType);
                        }

                        // Get distinct rows from the original DataTable
                        var distinctRows = dt.AsEnumerable().Distinct(DataRowComparer.Default);

                        // Add distinct rows to the new DataTable
                        foreach (DataRow row in distinctRows)
                        {
                            distinctDt.Rows.Add(row.ItemArray);
                        }

                        // Pass the distinct DataTable to the ViewBag
                        ViewBag.DataTable = distinctDt;

                        return View("ViewResult");
                    }

                }
            }
        }
        private Cell CreateCell(string value)
        {
            Cell cell = new Cell(new CellValue(value));
            cell.DataType = new EnumValue<CellValues>(CellValues.String);
            return cell;
        }
        public IActionResult Delete()
        {
            return View();
        }
        [HttpGet]
        public IActionResult ExecuteDelete(string id)
        {
            string connectionString = "Data Source=(local);Initial Catalog=FollowInvoices;Integrated Security=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string getId = @"SELECT Id FROM InvoiceDetails WHERE Id = @Id";

                // Execute your SQL query using the connection
                using (SqlCommand command = new SqlCommand(getId, connection))
                {
                    // Add parameters to the command
                    command.Parameters.AddWithValue("@Id", id);

                    // Execute the command and retrieve data
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        // Check if the DataTable has data
                        if (!(dt.Rows.Count > 0))
                        {
                            ViewBag.ErrorMessage = ".الفاتورة غير موجودة";
                            return View("Failed");
                        }
                    }
                }
                // Create the insert query with parameters to prevent SQL injection
                string insertQuery = @"DELETE FROM InvoiceDetails WHERE Id = @Id";

                // Execute the insert query using a parameterized SqlCommand
                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    // Add parameters to the command
                    command.Parameters.AddWithValue("@Id", id);
                    try
                    {
                        command.ExecuteNonQuery();
                        //throw new Exception("An error occurred.");
                    }
                    catch (Exception ex)
                    {
                        ViewBag.ErrorMessage = ex.Message;
                        return View("Failed");
                    }
                }

                // Redirect to another action after the insert
                return View("DoneDelete");
            }
        }
        public IActionResult Send()
        {
            return View("ThankYou");
        }
        public IActionResult ForgotPassword()
        {
            return View();
        }
        public async Task<IActionResult> Privacy()
        {
            return View();
        }
    }
}