﻿using ClosedXML.Excel;
using Microsoft.Extensions.Options;
using FollowInvoices.Models;
using FollowInvoices.Utilities;
using System.Data.SqlClient;
using System.Diagnostics;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting.Internal;
using System.IO;
using FollowInvoices.Data;
using DocumentFormat.OpenXml.InkML;
using Azure.Core;
using DocumentFormat.OpenXml.VariantTypes;
using DocumentFormat.OpenXml.EMMA;
using Microsoft.AspNetCore.Authorization;
using DocumentFormat.OpenXml.Office2010.Excel;
using System.Numerics;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using System.Security.Claims;

namespace FollowInvoices.Controllers
{
    public class AccountController : Controller
    {
        private readonly Dictionary<string, string> _users = new Dictionary<string, string>
    {
        { "user1", "password1" },
        { "user2", "password2" }
    };
        public IActionResult Login(string returnUrl = null)
        {
            // If the user is already authenticated, redirect them to the home page
            if (User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Index", "Home");
            }

            ViewData["ReturnUrl"] = returnUrl;
            return View();
        }

        [HttpPost]
        public JsonResult ValidateUser(string username, string password)
        {
            ViewBag.UserName = username;
            ViewBag.Password = password;
            // Validate the input
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                return Json(new { success = false, message = "Username and password are required." });
            }

            // Check if user exists and password matches
            if (_users.TryGetValue(username, out var storedPassword))
            {
                if (storedPassword == password)
                {
                    // Create claims
                    var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, username)
            };

                    // Create the identity and principal
                    var claimsIdentity = new ClaimsIdentity(claims, "MyCookieAuth");
                    var claimsPrincipal = new ClaimsPrincipal(claimsIdentity);

                    // Sign the user in
                    HttpContext.SignInAsync("MyCookieAuth", claimsPrincipal);

                    // Successful validation
                    return Json(new { success = true });
                }
                else
                {
                    return Json(new { success = false, message = "Invalid password." });
                }
            }
            else
            {
                return Json(new { success = false, message = "User not found." });
            }
        }


        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login", "Account");
        }
    }
}
