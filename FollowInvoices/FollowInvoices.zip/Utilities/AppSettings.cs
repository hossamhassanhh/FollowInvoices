﻿using Microsoft.Extensions.Configuration;

namespace FollowInvoices.Utilities
{
    public class AppSettings
    {
        public string ConnectionString { get; set; }
    }
}